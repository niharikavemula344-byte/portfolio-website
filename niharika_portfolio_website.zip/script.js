// You can add interactivity here later
console.log("Portfolio website loaded successfully!");
